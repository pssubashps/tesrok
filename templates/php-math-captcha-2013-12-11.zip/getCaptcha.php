<?php
require 'class.MathsCaptcha.php';
$C = new MathsCaptcha();
$C->generateCaptcha();